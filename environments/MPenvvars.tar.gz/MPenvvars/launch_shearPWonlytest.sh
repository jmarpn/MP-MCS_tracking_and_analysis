#!/bin/bash
#SBATCH -A m1867
#SBATCH -J noafwa
#SBATCH -t 03:00:00
#SBATCH -q regular
#SBATCH -C cpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=128
#SBATCH --exclusive
#SBATCH --output=log_mp_era5_envs_afwacommentout
#SBATCH --mail-type=END
#SBATCH --mail-user=james.marquis@pnnl.gov

date

conda activate JIMenv #/global/common/software/m1867/python/pyflex
#cd /global/u1/f/feng045/program/gpm_mcs_post/era5

python calc_era5_mp_envs_JIM_AFWAshearsfcaloft_commentAFWA.py -logfile LOG.noafwadebug.out       # calc_era5_mp_envs_shearsfcaloft.py 

date
