"""
Calculate mean ERA5 vertical profile from a 3D variable centered at each MCS and 
saves the output matching MCS tracks to a netCDF file.
"""
__author__ = "Zhe.Feng@pnnl.gov"
__date__ = "05-Aug-2021"

import numpy as np
import xarray as xr
import pandas as pd
import sys, os
import copy
import math
import time
import yaml
import dask
import statistics
import diag_functions as afwa
from dask.distributed import Client, LocalCluster

def calc_era5_prof(filenameZ, filenameT, filenameRH, filenameU, filenameV, mcs_time, mcs_lat, mcs_lon, level_lims, ny, nx):

    # Read ERA5 data
    dseZ = xr.open_dataset(filenameZ)
    dseT = xr.open_dataset(filenameT)
    dseR = xr.open_dataset(filenameRH)
    #dseU = xr.open_dataset(filenameU)
    #dseV = xr.open_dataset(filenameV)

    #reverse vert coord alignment (era5 puts top of astmo at first k index)
    dseZ = dseZ.reindex(level=list(reversed(dseZ.level)))
    dseT = dseT.reindex(level=list(reversed(dseT.level)))
    dseR = dseR.reindex(level=list(reversed(dseR.level)))
    #dseU = dseU.reindex(level=list(reversed(dseU.level)))
    #dseV = dseV.reindex(level=list(reversed(dseV.level)))

    #grab just the prescribed  pressure levels. 
    dseZ = dseZ.sel(level=slice(max(level_lims), min(level_lims)))
    dseT = dseT.sel(level=slice(max(level_lims), min(level_lims)))
    dseR = dseR.sel(level=slice(max(level_lims), min(level_lims)))
    #dseU = dseU.sel(level=slice(max(level_lims), min(level_lims)))
    #dseV = dseV.sel(level=slice(max(level_lims), min(level_lims)))    

    # grab coordinate frames
    lat_e5 = dseZ.latitude
    lon_e5 = dseZ.longitude
    time_e5 = dseZ.time
    pressure = dseZ.level

    # Number of tracks in the day
    ntracks_day = len(mcs_lat)
    nlevels = len(pressure) 
    
    # # Find level indices matching the limits
    # lev_idx = np.nonzero(np.in1d(dse.level.values, level.values))[0]
    # lev_idx0 = min(lev_idx)
    # lev_idx1 = max(lev_idx)

    # # Make array to store output
    meanMUCAPE = np.full((ntracks_day), np.NaN, dtype=float) 
    meanMUCIN = np.full((ntracks_day), np.NaN, dtype=float)
    meanMULFC = np.full((ntracks_day), np.NaN, dtype=float)
    meanMULCL = np.full((ntracks_day), np.NaN, dtype=float)
    meanMUEL = np.full((ntracks_day), np.NaN, dtype=float)        

    #medianMUCAPE = np.full((ntracks_day, nlevels), np.NaN, dtype=float)
    #medianMUCIN = np.full((ntracks_day, nlevels), np.NaN, dtype=float)
    #medianMULFC = np.full((ntracks_day, nlevels), np.NaN, dtype=float)
    #medianMULCL = np.full((ntracks_day, nlevels), np.NaN, dtype=float)
    #medianMUEL = np.full((ntracks_day, nlevels), np.NaN, dtype=float)

    maxMUCAPE = np.full((ntracks_day), np.NaN, dtype=float)
    #maxMUCIN = np.full((ntracks_day), np.NaN, dtype=float)
    #maxMULFC = np.full((ntracks_day), np.NaN, dtype=float)
    #maxMULCL = np.full((ntracks_day), np.NaN, dtype=float)
    maxMUEL = np.full((ntracks_day), np.NaN, dtype=float)   

    #minMUCAPE = np.full((ntracks_day), np.NaN, dtype=float)
    minMUCIN = np.full((ntracks_day), np.NaN, dtype=float)
    minMULFC = np.full((ntracks_day), np.NaN, dtype=float)
    minMULCL = np.full((ntracks_day), np.NaN, dtype=float)
    #minMUEL = np.full((ntracks_day), np.NaN, dtype=float)


    print(f' ntracks_day {ntracks_day} ')
    
    # Loop over each MCS
    for itrack in range(0, ntracks_day):
        print(f'{itrack}: {mcs_time[itrack]}')
        
        # Find closest grid point and time index in ERA5 
        lat_idx = np.abs(lat_e5.values - mcs_lat[itrack]).argmin()
        lon_idx = np.abs(lon_e5.values - mcs_lon[itrack]).argmin()
        t5_idx = np.abs(time_e5.values - mcs_time[itrack]).argmin()


        # Select the time, level, and region
        # Note index+1 is needed to include the last value in the range
        
        iT = dseT.isel(time=t5_idx, \
            latitude=slice(lat_idx-ny, lat_idx+ny+1), \
            longitude=slice(lon_idx-nx, lon_idx+nx+1))

        iR = dseR.isel(time=t5_idx, \
            latitude=slice(lat_idx-ny, lat_idx+ny+1), \
            longitude=slice(lon_idx-nx, lon_idx+nx+1))

        iZ = dseZ.isel(time=t5_idx, \
            latitude=slice(lat_idx-ny, lat_idx+ny+1), \
            longitude=slice(lon_idx-nx, lon_idx+nx+1))

        #iU = dseU.isel(time=t5_idx, \
        #    latitude=slice(lat_idx-ny, lat_idx+ny+1), \
        #    longitude=slice(lon_idx-nx, lon_idx+nx+1))

        #iV = dseV.isel(time=t5_idx, \
        #    latitude=slice(lat_idx-ny, lat_idx+ny+1), \
        #    longitude=slice(lon_idx-nx, lon_idx+nx+1))

        # dumbdown to values 
        profT3d   = iT.T.values
        profRH3d  = iR.R.values
        #profU3d   = iU.U.values
        #profV3d   = iV.V.values
        profG3d   = iZ.Z.values   #geopotential
        grav  = 9.8
        Re    = 6370000.0
        profZ3d = ( profG3d * Re )/( grav*Re - profG3d )  #geometric ht (m)
        profP = pressure.values
        profP = profP*100

        #make a 3D pressure field
        profP3d = copy.deepcopy(profT3d)
        kk,xx,yy = profP3d.shape 
        #print( profP3d.shape  )
        for i in range(0,xx):
            for j in range(0,yy):
                profP3d[:,i,j] = profP 

        ##permute to f(x,y,t)
        #profTp = np.transpose(profT, (2,1,0))
        #profRHp = np.transpose(profRH, (2,1,0))
        #profPp = np.transpose(profP3d, (2,1,0))
        #profZp = np.transpose(profZ, (2,1,0))

        ostat,afwaMUCAPE, afwaMUCIN, afwaMULCL, afwaMULFC, afwaMUEL, afwaMULPL = afwa.diag_functions.diag_map(profT3d, profRH3d, profP3d, profZ3d, 1, 1)

        #get rid of -999999 values by convert to nan
        badcape = np.argwhere(afwaMUCAPE < -9999.)
        badcin = np.argwhere(afwaMUCIN < -9999.)
        badlfc = np.argwhere(afwaMULFC < -9999.)
        badel = np.argwhere(afwaMUEL < -9999.)
        afwaMUCAPE[badcape[:,0],badcape[:,1]] = math.nan
        afwaMUCIN[badcin[:,0],badcin[:,1]] = math.nan
        afwaMULFC[badlfc[:,0],badlfc[:,1]] = math.nan
        afwaMUEL[badel[:,0],badel[:,1]] = math.nan

        ## Check box size to avoid error (e.g. at date line)
        #if (dseT.sizes['latitude'] > 1) & (dseT.sizes['longitude'] > 1):
            #VAR_avg[itrack,:] = dseT.T.mean( dim=('level') ).values
            #VAR_avg[itrack,:] = statistics.mean(iTv)
            #VAR_avg[itrack,:] = dseT.T.mean(dim=('latitude', 'longitude')).values
            #VAR_max[itrack,:] = dseT.T.max(dim=('latitude', 'longitude')).values
            #VAR_min[itrack,:] = dseT.T.max(dim=('latitude', 'longitude')).values

        ## calculate stats of afwa vars:
        meanMUCAPE[itrack] = np.nanmean(afwaMUCAPE)
        meanMUCIN[itrack]  = np.nanmean(afwaMUCIN)
        meanMULFC[itrack]  = np.nanmean(afwaMULFC)
        meanMULCL[itrack]  = np.nanmean(afwaMULCL)
        meanMUEL[itrack]   = np.nanmean(afwaMUEL)        

        #medianMUCAPE[itrack] = np.nanmedian(afwaMUCAPE)
        #medianMUCIN[itrack]  = np.nanmedian(afwaMUCIN)
        #medianMULFC[itrack]  = np.nanmedian(afwaMULFC)
        #medianMULCL[itrack]  = np.nanmedian(afwaMULCL)
        #medianMUEL[itrack]   = np.nanmedian(afwaMUEL)

        maxMUCAPE[itrack] = np.nanmax(afwaMUCAPE)
        #maxMUCIN[itrack]  = np.nanmax(afwaMUCIN)
        #maxMULFC[itrack]  = np.nanmax(afwaMULFC)
        #maxMULCL[itrack]  = np.nanmax(afwaMULCL)
        maxMUEL[itrack]   = np.nanmax(afwaMUEL)  

        #minMUCAPE[itrack] = np.nanmin(afwaMUCAPE)
        minMUCIN[itrack]  = np.nanmin(afwaMUCIN)
        minMULFC[itrack]  = np.nanmin(afwaMULFC)
        minMULCL[itrack]  = np.nanmin(afwaMULCL)
        #minMUEL[itrack]   = np.nanmin(afwaMUEL)

    ## define attributes for output vars
    MUCAPE_attrs = {'long_name': 'MU CAPE in area', 'units': 'J/kg' }
    MUCIN_attrs  = {'long_name': 'MU CIN  in area', 'units': 'J/kg' }
    MULCL_attrs  = {'long_name': 'MU LCL in area', 'units': 'm ASL'}
    MULFC_attrs  = {'long_name': 'MU LFC in area', 'units': 'm ASL'}
    MUEL_attrs   = {'long_name': 'MU EL in area', 'units': 'm ASL'}

    #maxMUCAPE_attrs = {'long_name': 'max MU CAPE in area', 'units': 'J/kg' }
    #maxMUCIN_attrs  = {'long_name': 'max MU CIN (i.e., least oppressive CIN) in area', 'units': 'J/kg' }
    #maxMULCL_attrs  = {'long_name': 'max MU LCL in area', 'units': 'm ASL'}
    #maxMULFC_attrs  = {'long_name': 'max MU LFC in area', 'units': 'm ASL'}
    #maxMUEL_attrs   = {'long_name': 'max MU EL in area', 'units': 'm ASL'}

    #minMUCAPE_attrs = {'long_name': 'min MU CAPE in area', 'units': 'J/kg' }
    #minMUCIN_attrs  = {'long_name': 'min MU CIN (i.e., most oppressive CIN) in area', 'units': 'J/kg' }
    #minMULCL_attrs  = {'long_name': 'min MU LCL in area', 'units': 'm ASL'}
    #minMULFC_attrs  = {'long_name': 'min MU LFC in area', 'units': 'm ASL'}
    #minMUEL_attrs   = {'long_name': 'min MU EL in area', 'units': 'm ASL'}

    #meanMUCAPE_attrs = {'long_name': 'mean MU CAPE in area', 'units': 'J/kg' }
    #meanMUCIN_attrs  = {'long_name': 'mean MU CIN in area', 'units': 'J/kg' }
    #meanMULCL_attrs  = {'long_name': 'mean MU LCL in area', 'units': 'm ASL'}
    #meanMULFC_attrs  = {'long_name': 'mean MU LFC in area', 'units': 'm ASL'}
    #meanMUEL_attrs   = {'long_name': 'mean MU EL in area', 'units': 'm ASL'}

    #medianMUCAPE_attrs = {'long_name': 'median MU CAPE in area', 'units': 'J/kg' }
    #medianMUCIN_attrs  = {'long_name': 'median MU CIN in area', 'units': 'J/kg' }
    #medianMULCL_attrs  = {'long_name': 'median MU LCL in area', 'units': 'm ASL'}
    #medianMULFC_attrs  = {'long_name': 'median MU LFC in area', 'units': 'm ASL'}
    #medianMUEL_attrs   = {'long_name': 'median MU EL in area', 'units': 'm ASL'}
    
    ## Put output variables to a dictionary for easier acceess
    #out_dict = {'meanMUCAPE':meanMUCAPE, 'maxMUCAPE':maxMUCAPE, 'minMUCAPE':minMUCAPE, 'MUCAPE_attrs':MUCAPE_attrs,
    #            'meanMUCIN':meanMUCIN,   'maxMUCIN':maxMUCIN,   'minMUCIN':minMUCIN,   'MUCIN_attrs':MUCIN_attrs,
    #            'meanMULFC':meanMULFC,   'maxMULFC':maxMULFC,   'minMULFC':minMULFC,   'MULFC_attrs':MULFC_attrs,
    #            'meanMULCL':meanMULCL,   'maxMULCL':maxMULCL,   'minMULCL':minMULCL,   'MULCL_attrs':MULCL_attrs,
    #            'meanMUEL':meanMUEL,     'maxMUEL':maxMUEL,     'minMUEL':minMUEL,     'MUEL_attrs':MUEL_attrs} 

    out_dict = {'meanMUCAPE':meanMUCAPE, 'maxMUCAPE':maxMUCAPE, 'MUCAPE_attrs':MUCAPE_attrs,
                'meanMUCIN':meanMUCIN,   'minMUCIN':minMUCIN,   'MUCIN_attrs':MUCIN_attrs,
                'meanMULFC':meanMULFC,   'minMULFC':minMULFC,   'MULFC_attrs':MULFC_attrs,
                'meanMULCL':meanMULCL,   'minMULCL':minMULCL,   'MULCL_attrs':MULCL_attrs,
                'meanMUEL':meanMUEL,     'maxMUEL':maxMUEL,     'MUEL_attrs':MUEL_attrs}

    print(f'Done processing: {filenameT}')
    
    return out_dict


def main():


    # hardcode set inputs:
    era5_dir = '/pscratch/sd/j/jmarquis/era5data/'
    
    #for MCSs
    stats_dir = '/pscratch/sd/j/jmarquis/ERA5_waccem/MCStracking/allstats/'
    output_dir = '/pscratch/sd/j/jmarquis/ERA5_waccem/Bandpassed/MCSenvs/'
    mcsfile_basename = 'mcs_tracks_final_'

    # # for MPs
    #stats_dir = '/pscratch/sd/j/jmarquis/ERA5_waccem/Bandpassed/vortstats/'
    #output_dir = '/pscratch/sd/j/jmarquis/ERA5_waccem/Bandpassed/MPenvs/'
    #mcsfile_basename = 'trackstats_final_'

    varname = 'liftparcmetrics'
    track_period = '20040101.0000_20050101.0000'
    nx = 3 #+/- num of era5 grid points from object centroid
    ny = 3
    level_lims = [1000,100]  # 100mb, 1000mb
    # nlevels = config['nlevels']
    run_parallel = 0
    n_workers = 1
    threads_per_worker = 1

    mcs_file = f"{stats_dir}{mcsfile_basename}{track_period}.nc"
    outfilename = f"{output_dir}mcs_tracks_era5_{varname}_{track_period}.nc"
    os.makedirs(output_dir, exist_ok=True)

    print(f'mcs_file:     {mcs_file}')
    print(f'outfile:      {output_dir}{outfilename}')


    # Read robust MCS statistics
    dsm = xr.open_dataset(mcs_file)
    ntracks = dsm.sizes['tracks']
    ntimes = dsm.sizes['times']
    #print(f'start ntimes:  {ntimes}')

    rmcs_lat = dsm['meanlat']
    rmcs_lon = dsm['meanlon']

    # Check if longitude is [-180~+180], if so convert it to [0~360] to match ERA5
    if np.nanmin(rmcs_lon) < 0:
        rmcs_lon = rmcs_lon % 360
        print('MCS longitudes are [-180~+180], converted to [0-360] to match ERA5.')

    # Get end times for all tracks
    rmcs_basetime = dsm.base_time
    # Sum over time dimension for valid basetime indices, -1 to get the last valid time index for each track
    # This is the end time index of each track (i.e. +1 equals the lifetime of each track)
    end_time_idx = np.sum(np.isfinite(rmcs_basetime), axis=1)-1
    # Apply fancy indexing to base_time: a tuple that indicates for each track, get the end time index
    end_basetime = rmcs_basetime[(np.arange(0,ntracks), end_time_idx)]

    # Get the min/max of all base_times
    min_basetime = rmcs_basetime.sel(times=0).min()
    max_basetime = end_basetime.max()
    
    # Make a date list that includes all tracks
    mcs_alldates = pd.date_range(start=min_basetime.values, end=max_basetime.values, freq='1D')
    # Convert all MCS times and ERA5 times to date strings
    rmcs_dates = rmcs_basetime.dt.strftime('%Y%m%d')
    # ERA5 data directory is organized by month (yyyymm)
    dirs_month = mcs_alldates.strftime("%Y%m")
    # 3D data is in daily files
    files3d_day = mcs_alldates.strftime("%Y%m%d")
    nfiles = len(mcs_alldates)
    print(f"Total number of ERA5 files: {nfiles}")

    #print(f"mcs_alldates: {list(mcs_alldates)}")

    # #diagnostic hack:
    # #print(f'nfiles   {nfiles}')
    #print(f'day day   {files3d_day[121]}')
    #nfiles = 121
    #print(f'nfiles   {nfiles}')

    # Create a list to store matchindices for each ERA5 file
    trackindices_all = []
    timeindices_all = []
    results = []

    # Run in serial or parallel
    if run_parallel == 0:

        # Loop over dates that have MCSs in them
        #for ifile in range(nfiles):   #use this for complete run
        for ifile in range(121,128):   #use 121-122 for may 1
            print(f'calc ifile     {ifile}')
            idir = dirs_month[ifile]
            iday = files3d_day[ifile]
            print('iday')
            print(iday)

            #jmon = np.array2string(iday)
            jmon = iday[4:6]  #the current day's month
            #print(jmon)

            #proceed with calculating if it's a target summer month
            if jmon == '05' or jmon == '06' or jmon == '07' or jmon == '08':
                #print('jmon = ')
                #print(jmon)

                ## filename = f"{era5_dir}{idir}/{basename}{iday}00_{iday}23.nc"
                ## print(filename)
                 
                #3d era5 var files for the day: 
                filenameT = f"{era5_dir}{idir}/e5.oper.an.pl.128_130_t.ll025sc.{iday}00_{iday}23.nc"
                filenameRH = f"{era5_dir}{idir}/e5.oper.an.pl.128_157_r.ll025sc.{iday}00_{iday}23.nc"
                filenameU = f"{era5_dir}{idir}/e5.oper.an.pl.128_131_u.ll025uv.{iday}00_{iday}23.nc"
                filenameV = f"{era5_dir}{idir}/e5.oper.an.pl.128_132_v.ll025uv.{iday}00_{iday}23.nc"
                filenameZ = f"{era5_dir}{idir}/e5.oper.an.pl.128_129_z.ll025sc.{iday}00_{iday}23.nc"

                print(filenameZ)

                # Get all MCS tracks/times indices that are in the same day
                
                # These tracks use the same ERA5 file
                idx_track, idx_time = np.where(rmcs_dates == files3d_day[ifile])

                
                # # jim diagnostics
                print(f'day    {iday}')
                print(f'idx_track    {idx_track}') #jimnotes: individual IDs of MCSs present this day * number of hours they exist in today's 24hr period. 
                print(f'idx_time    {idx_time}')   #jimnotes: time indices during those MCSs' lifetimes for this day

                # Save track/time indices for the current ERA5 file to the overall list
                trackindices_all.append(idx_track)
                timeindices_all.append(idx_time)

                # Get the track lat/lon/time values in the same day
                mcs_lat = rmcs_lat.values[idx_track, idx_time]
                mcs_lon = rmcs_lon.values[idx_track, idx_time]
                mcs_time = rmcs_basetime.values[idx_track, idx_time]
           

                # check if there are MCSs at current era5 time:
                mcs_present =  len(mcs_time) 
                print(f'mcs_present   {mcs_present} ')


                #if mcs present at era5 time 
                if mcs_present > 0:
                    # Call function to calculate statistics
                    #result = calc_era5_prof(filename, mcs_time, mcs_lat, mcs_lon, level_lims, ny, nx, varname)
                    result = calc_era5_prof(filenameZ, filenameT, filenameRH, filenameU, filenameV, mcs_time, mcs_lat, mcs_lon, level_lims, ny, nx)
                    results.append(result)


                    #print('results after calc call')
                    #print(results)

                #if no mcs present at era5 time    
                elif mcs_present == 0:
                    result = -999.0
                    results.append(result)

                # Serial
                final_result = results
                
                #print('final_result')
                #print(final_result)


    elif run_parallel == 1:

        # Initialize dask
        cluster = LocalCluster(n_workers=n_workers, threads_per_worker=threads_per_worker)
        client = Client(cluster)

        # Loop over each ERA5 file
        for ifile in range(nfiles):
            idir = dirs_month[ifile]
            iday = files3d_day[ifile]
            
            #filename = f"{era5_dir}{idir}/{basename}{iday}00_{iday}23.nc"
            #print(filename)
            
            ## filename = f"{era5_dir}{idir}/{basename}{iday}00_{iday}23.nc"
            ## print(filename)

            filenameT = f"{era5_dir}{idir}/e5.oper.an.pl.128_130_t.ll025sc.{iday}00_{iday}23.nc"
            filenameRH = f"{era5_dir}{idir}/e5.oper.an.pl.128_157_r.ll025sc.{iday}00_{iday}23.nc"
            filenameU = f"{era5_dir}{idir}/e5.oper.an.pl.128_131_u.ll025uv.{iday}00_{iday}23.nc"
            filenameV = f"{era5_dir}{idir}/e5.oper.an.pl.128_132_v.ll025uv.{iday}00_{iday}23.nc"
            filenameZ = f"{era5_dir}{idir}/e5.oper.an.pl.128_129_v.ll025sc.{iday}00_{iday}23.nc"

            print(filenameT)
            print(filenameRH)
            print(filenameU)
            print(filenameZ)
            print(filenameV)

            # Get all MCS tracks/times indices that are in the same day
            # These tracks use the same ERA5 file
            idx_track, idx_time = np.where(rmcs_dates == files3d_day[ifile])
            # Save track/time indices for the current ERA5 file to the overall list
            trackindices_all.append(idx_track)
            timeindices_all.append(idx_time)

            # Get the track lat/lon/time values in the same day
            mcs_lat = rmcs_lat.values[idx_track, idx_time]
            mcs_lon = rmcs_lon.values[idx_track, idx_time]
            mcs_time = rmcs_basetime.values[idx_track, idx_time]
            
            # Call function to calculate statistics
            result = dask.delayed(calc_era5_prof)(filename, mcs_time, mcs_lat, mcs_lon, level_lims, ny, nx, varname)
            results.append(result)

        # Trigger dask computation
        final_result = dask.compute(*results)



#
# # ###################   done calculating
#

    #  # Create variables for saving output
    fillval = np.NaN

    meanMUCAPE = np.full((ntracks, ntimes), fillval, dtype=float)
    maxMUCAPE  = np.full((ntracks, ntimes), fillval, dtype=float)
    #minMUCAPE  = np.full((ntracks, ntimes), fillval, dtype=float)

    meanMUCIN = np.full((ntracks, ntimes), fillval, dtype=float)
    #maxMUCIN  = np.full((ntracks, ntimes), fillval, dtype=float)
    minMUCIN  = np.full((ntracks, ntimes), fillval, dtype=float)

    meanMULFC = np.full((ntracks, ntimes), fillval, dtype=float)
    #maxMULFC  = np.full((ntracks, ntimes), fillval, dtype=float)
    minMULFC  = np.full((ntracks, ntimes), fillval, dtype=float)

    meanMULCL = np.full((ntracks, ntimes), fillval, dtype=float)
    #maxMULCL  = np.full((ntracks, ntimes), fillval, dtype=float)
    minMULCL  = np.full((ntracks, ntimes), fillval, dtype=float)

    meanMUEL = np.full((ntracks, ntimes), fillval, dtype=float)
    maxMUEL  = np.full((ntracks, ntimes), fillval, dtype=float)
    #minMUEL  = np.full((ntracks, ntimes), fillval, dtype=float)

    # Put the results to output track stats variables
    # Loop over each file (parallel return results)

#    for ifile in range(nfiles):    #use this for full run
    for ifile in range(0,4):     #this is jus for running on a shorter set of days

        # Get the return results for this pixel file
     
        #print(f'ifile   {ifile}')
        
        iVAR = final_result[ifile]   #keeps crashing on this line. Do I have the dictionary incorrectly defined?
 
        #print('ivar')
        #print(iVAR)

        #if iVAR is not None:   #Zhe original line
        if iVAR is not None and iVAR != -999.0:    #jim added the  -999 for case when no MCSs on a day         
            trackindices = trackindices_all[ifile]
            timeindices = timeindices_all[ifile]
            
            # Put variable to the MCS track array
            meanMUCAPE[trackindices, timeindices] = iVAR['meanMUCAPE']
            maxMUCAPE[trackindices, timeindices] = iVAR['maxMUCAPE']
            #minMUCAPE[trackindices, timeindices] = iVAR['minMUCAPE']

            meanMUCIN[trackindices, timeindices] = iVAR['meanMUCIN']
            #maxMUCIN[trackindices, timeindices] = iVAR['maxMUCIN']
            minMUCIN[trackindices, timeindices] = iVAR['minMUCIN']

            meanMULFC[trackindices, timeindices] = iVAR['meanMULFC']
            #maxMULFC[trackindices, timeindices] = iVAR['maxMULFC']
            minMULFC[trackindices, timeindices] = iVAR['minMULFC']

            meanMULCL[trackindices, timeindices] = iVAR['meanMULCL']
            #maxMULCL[trackindices, timeindices] = iVAR['maxMULCL']
            minMULCL[trackindices, timeindices] = iVAR['minMULCL']

            meanMUEL[trackindices, timeindices] = iVAR['meanMUEL']
            maxMUEL[trackindices, timeindices] = iVAR['maxMUEL']
            #minMUEL[trackindices, timeindices] = iVAR['minMUEL']

        else:
            print(f'ifile result empty, skipping because no MCSs then')


    # jim check
    MUCAPE_attrs = final_result[0]['MUCAPE_attrs']
    MUCIN_attrs = final_result[0]['MUCIN_attrs']
    MULFC_attrs = final_result[0]['MULFC_attrs']
    MULCL_attrs = final_result[0]['MULCL_attrs']
    MUEL_attrs = final_result[0]['MUEL_attrs']
    
    # Define output dataset
    varlist = {
        ## 'base_time': (['tracks', 'times'], rmcs_basetime, rmcs_basetime.attrs), 
        ## 'meanlat': (['tracks', 'times'], rmcs_lat, rmcs_lat.attrs),
        ## 'meanlon': (['tracks', 'times'], rmcs_lon, rmcs_lon.attrs),
        f"meanMUCAPE": (['tracks', 'times'], meanMUCAPE, MUCAPE_attrs),
        f"maxMUCAPE": (['tracks', 'times'],  maxMUCAPE,  MUCAPE_attrs),
        #f"minMUCAPE": (['tracks', 'times'],  minMUCAPE,  MUCAPE_attrs),

        f"meanMUCIN": (['tracks', 'times'], meanMUCIN, MUCIN_attrs),
        #f"maxMUCIN": (['tracks', 'times'],  maxMUCIN,  MUCIN_attrs),
        f"minMUCIN": (['tracks', 'times'],  minMUCIN,  MUCIN_attrs),

        f"meanMULFC": (['tracks', 'times'], meanMULFC, MULFC_attrs),
        #f"maxMULFC": (['tracks', 'times'],  maxMULFC,  MULFC_attrs),
        f"minMULFC": (['tracks', 'times'],  minMULFC,  MULFC_attrs), 

        f"meanMULCL": (['tracks', 'times'], meanMULCL, MULCL_attrs),
        #f"maxMULCL": (['tracks', 'times'],  maxMULCL,  MULCL_attrs),
        f"minMULCL": (['tracks', 'times'],  minMULCL,  MULCL_attrs), 

        f"meanMUEL": (['tracks', 'times'], meanMUEL, MUEL_attrs),
        f"maxMUEL": (['tracks', 'times'],  maxMUEL,  MUEL_attrs),
        #f"minMUEL": (['tracks', 'times'],  minMUEL,  MUEL_attrs)
    }
  

    coordlist = {
        'tracks': (['tracks'], dsm['tracks'].values, dsm['tracks'].attrs),
        'times': (['times'], dsm['times'].values, dsm['times'].attrs)
    }
    

    gattrlist = {
        'Title': 'MCS environments from ERA5',
        'lon_box_size': nx*2+1,
        'lat_box_size': ny*2+1,
        'Institution': 'Pacific Northwest National Laboratoy',
        'Contact': 'zhe.feng@pnnl.gov',
        'Created_on': time.ctime(time.time()),
    }

    # Define xarray dataset
    dsout = xr.Dataset(varlist, coords=coordlist, attrs=gattrlist)

    # Set encoding/compression for all variables
    comp = dict(zlib=True, dtype='float32')
    encoding = {var: comp for var in dsout.data_vars}
    # Update base_time variable dtype as 'double' for better precision
    # bt_dict = {'base_time': {'zlib':True, 'dtype':'float64'}}
    # encoding.update(bt_dict)

    # Write to netcdf file
    dsout.to_netcdf(path=outfilename, mode='w', format='NETCDF4', 
                    unlimited_dims='tracks', encoding=encoding)
    print(f"Output saved as: {outfilename}")


if __name__ == "__main__":
    main()
