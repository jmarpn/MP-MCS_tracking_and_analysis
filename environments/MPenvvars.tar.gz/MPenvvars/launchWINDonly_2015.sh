#!/bin/bash
#SBATCH -A m1867
#SBATCH -J win15 
#SBATCH -t 24:00:00
#SBATCH -q regular 
#SBATCH -C cpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=128
#SBATCH --exclusive
#SBATCH --output=log_mp_era5_envs_WINDonly2015.log
#SBATCH --mail-type=END
#SBATCH --mail-user=james.marquis@pnnl.gov

date

module load python
conda activate JIMenv #/global/common/software/m1867/python/pyflex
#cd /global/u1/f/feng045/program/gpm_mcs_post/era5

python  calc_era5_mp_envs_winds_2015.py  -logfile  LOG.wind.only_2015.out       # calc_era5_mp_envs_shearsfcaloft.py 

date
