"""
Calculate representative ERA5 environments within each tracked object mask and 
saves the output matching track statistics to a netCDF file.
This version processes a subset of tracks provided from input arguments.
"""
__author__ = "Zhe.Feng@pnnl.gov"
__date__ = "02-19-2024"

import numpy as np
import xarray as xr
import pandas as pd
import sys, os
import copy
import time
import yaml
import warnings
import diag_functions as afwa
import metpy
from metpy.units import units
from pandas.tseries.offsets import MonthEnd
from wrf import getvar, interplevel
from itertools import repeat
from multiprocessing import Pool
from joblib import Parallel, delayed

def calc_era5_prof(
        filenameZ,
        filenameT,
        filenameRH,
        filenameU,
        filenameV,
        filenameW,
        filenameD,
        filenameU10,
        filenameV10,
        filenameVIWVD,
        idx_track,
        track_time,
        level_lims,
        iday):

#filenameZ, filenameT, filenameRH, filenameU, filenameV, filenameW, filenameD, filenameU10, filenameV10, filenameVIWVD, _coord_tracks, track_time, level_lims, iday

    print(f'in calc_era5_prof filenameZ     {filenameZ}')

    print(f'idx_track topofcalc_era5_prof         {idx_track}')


    # Find unique track_times
    unique_track_time = np.unique(track_time)
    n_unique_maskfiles = len(unique_track_time)
    # Make a list for all tracking mask files for this day
    mask_filenames = []
    for ifile in range(n_unique_maskfiles):
        # Convert current track time to a datetime string matching the mask file format
        track_timestring = pd.to_datetime(unique_track_time[ifile]).strftime('%Y%m%d_%H%M%S')
        # Tracking mask filename
        mask_filename = f'{mask_dir}{trackmask_basename}{track_timestring}.nc'
        maskfile_exist = os.path.isfile(mask_filename)
        if maskfile_exist:
            mask_filenames.append(mask_filename)
        else:
            print(f'WARNING: tracking mask file is missing: {mask_filename}')

    # Read and combine all tracking mask files
    dsm = xr.open_mfdataset(mask_filenames, concat_dim='time', combine='nested')
    # Drop the 2D latitude/longitude variables
    dsm = dsm.drop_vars(['longitude','latitude'])
    # Rename the lat/lon dimensions to latitude/longitude to be consistent with ERA5 dimension names
    # This is needed in Xarray for masking between different DataSets
    dsm = dsm.rename({'lon':'longitude', 'lat':'latitude'})
    # Get the min/max lat/lon from the mask file
    lon_m = dsm['longitude']
    lat_m = dsm['latitude']
    min_lon, max_lon = lon_m.min().item(), lon_m.max().item()
    min_lat, max_lat = lat_m.min().item(), lat_m.max().item()
    # Get variables from mask file
    time_mask = dsm['time']
    mask_tracknumbers = dsm['cloudtracknumber']
    PW = dsm['PW']

    print(f'idx_track midcalc_era5_prof         {idx_track}')

    # Read ERA5 data, subset domain to match mask file
    dseZ = xr.open_dataset(filenameZ).sel(latitude=slice(max_lat, min_lat), longitude=slice(min_lon, max_lon))
    #dseT = xr.open_dataset(filenameT).sel(latitude=slice(max_lat, min_lat), longitude=slice(min_lon, max_lon))
    #dseR = xr.open_dataset(filenameRH).sel(latitude=slice(max_lat, min_lat), longitude=slice(min_lon, max_lon))
    dseZsfc = xr.open_dataset(era5_terrain_file).sel(latitude=slice(max_lat, min_lat), longitude=slice(min_lon, max_lon))

    dseU = xr.open_dataset(filenameU).sel(latitude=slice(max_lat, min_lat), longitude=slice(min_lon, max_lon))
    dseV = xr.open_dataset(filenameV).sel(latitude=slice(max_lat, min_lat), longitude=slice(min_lon, max_lon))
    dseW = xr.open_dataset(filenameW).sel(latitude=slice(max_lat, min_lat), longitude=slice(min_lon, max_lon))
    dseD = xr.open_dataset(filenameD).sel(latitude=slice(max_lat, min_lat), longitude=slice(min_lon, max_lon))

    todaystart = f"{iday[0:4]}-{iday[4:6]}-{iday[6:8]}T00:00:00.000000000"
    todaystop  = f"{iday[0:4]}-{iday[4:6]}-{iday[6:8]}T23:00:00.000000000"
    dseU10    = xr.open_dataset(filenameU10).sel(time=slice(todaystart,todaystop), latitude=slice(max_lat, min_lat), longitude=slice(min_lon, max_lon))
    dseV10    = xr.open_dataset(filenameV10).sel(time=slice(todaystart,todaystop), latitude=slice(max_lat, min_lat), longitude=slice(min_lon, max_lon))
    dseVIWVD  = xr.open_dataset(filenameVIWVD).sel(time=slice(todaystart,todaystop), latitude=slice(max_lat, min_lat), longitude=slice(min_lon, max_lon))


    # Reverse vertical coordinate (era5 puts top of atmos at first k index)
    dseZ = dseZ.reindex(level=list(reversed(dseZ.level)))
    #dseT = dseT.reindex(level=list(reversed(dseT.level)))
    #dseR = dseR.reindex(level=list(reversed(dseR.level)))
    dseU = dseU.reindex(level=list(reversed(dseU.level)))
    dseV = dseV.reindex(level=list(reversed(dseV.level)))
    dseW = dseW.reindex(level=list(reversed(dseW.level)))
    dseD = dseD.reindex(level=list(reversed(dseD.level)))

    # Subset pressure levels (reduce unncessary levels in the stratosphere)
    dseZ = dseZ.sel(level=slice(max(level_lims), min(level_lims)))
    #dseT = dseT.sel(level=slice(max(level_lims), min(level_lims)))
    #dseR = dseR.sel(level=slice(max(level_lims), min(level_lims)))
    dseU = dseU.sel(level=slice(max(level_lims), min(level_lims)))
    dseV = dseV.sel(level=slice(max(level_lims), min(level_lims)))
    dseD = dseD.sel(level=slice(max(level_lims), min(level_lims)))
    dseW = dseW.sel(level=slice(max(level_lims), min(level_lims)))





    # Get surface elevation [m]
    z_sfc = dseZsfc['Z'].squeeze() / 9.80665

    # grab coordinate frames
    # lat_e5 = dseZ.latitude
    # lon_e5 = dseZ.longitude
    time_e5 = dseZ.time
    #level = dseZ.level  #pressure level
    pressure = dseZ.level
    # Convert pressure unit to Pa
    pressure_pa = pressure.data * 100

    # Number of tracks in the day
    # ntracks_day = 5
    ntracks_day = len(track_time)
    nlevels = len(pressure)

    # # Find level indices matching the limits
    # lev_idx = np.nonzero(np.in1d(dse.level.values, level.values))[0]
    # lev_idx0 = min(lev_idx)
    # lev_idx1 = max(lev_idx)

    # Make arrays to store output
    #meanMUCAPE = np.full((ntracks_day), np.NaN, dtype=np.float32) 
    #meanMUCIN = np.full((ntracks_day), np.NaN, dtype=np.float32)
    #meanMULFC = np.full((ntracks_day), np.NaN, dtype=np.float32)
    #meanMULCL = np.full((ntracks_day), np.NaN, dtype=np.float32)
    #meanMUEL = np.full((ntracks_day), np.NaN, dtype=np.float32)        

    #maxMUCAPE = np.full((ntracks_day), np.NaN, dtype=np.float32)
    #maxMUCIN = np.full((ntracks_day), np.NaN, dtype=np.float32)
    #maxMULFC = np.full((ntracks_day), np.NaN, dtype=np.float32)
    #maxMULCL = np.full((ntracks_day), np.NaN, dtype=np.float32)
    #maxMUEL = np.full((ntracks_day), np.NaN, dtype=np.float32)   

    #minMUCAPE = np.full((ntracks_day), np.NaN, dtype=np.float32)
    #minMUCIN = np.full((ntracks_day), np.NaN, dtype=np.float32)
    #minMULFC = np.full((ntracks_day), np.NaN, dtype=np.float32)
    #minMULCL = np.full((ntracks_day), np.NaN, dtype=np.float32)
    #minMUEL = np.full((ntracks_day), np.NaN, dtype=np.float32)

    #meanPW = np.full((ntracks_day), np.NaN, dtype=np.float32)
    #maxPW = np.full((ntracks_day), np.NaN, dtype=np.float32)
    #minPW = np.full((ntracks_day), np.NaN, dtype=np.float32)


    # shear vars
    mean_shearmag_0to2 = np.full((ntracks_day), np.NaN, dtype=np.float32)
    max_shearmag_0to2  = np.full((ntracks_day), np.NaN, dtype=np.float32)
    mean_shearmag_0to6 = np.full((ntracks_day), np.NaN, dtype=np.float32)
    max_shearmag_0to6  = np.full((ntracks_day), np.NaN, dtype=np.float32)
    mean_shearmag_2to9 = np.full((ntracks_day), np.NaN, dtype=np.float32)
    max_shearmag_2to9  = np.full((ntracks_day), np.NaN, dtype=np.float32)
    #omega vars
    meanOMEGA600   = np.full((ntracks_day), np.NaN, dtype=np.float32)
    minOMEGA600    = np.full((ntracks_day), np.NaN, dtype=np.float32)
    minOMEGAsub600 = np.full((ntracks_day), np.NaN, dtype=np.float32)
    #divergence vars
    meanVIWVD      = np.full((ntracks_day), np.NaN, dtype=np.float32)
    minVIWVD       = np.full((ntracks_day), np.NaN, dtype=np.float32)
    maxVIWVD       = np.full((ntracks_day), np.NaN, dtype=np.float32)
    meanDIV750     = np.full((ntracks_day), np.NaN, dtype=np.float32)
    minDIV750      = np.full((ntracks_day), np.NaN, dtype=np.float32)
    minDIVsub600   = np.full((ntracks_day), np.NaN, dtype=np.float32)
    #in-mp winds
    meanWNDSPD600   = np.full((ntracks_day), np.NaN, dtype=np.float32)
    meanWNDDIR600   = np.full((ntracks_day), np.NaN, dtype=np.float32)

    print(f' ntracks_day {ntracks_day} ')
    

    #TESTER subset:
    # ntracks_day = 5


    print('   ')
    print(f'idx_track lastpreloop       {idx_track}')
    print('   ')
    


    # Loop over each track
    for itrack in range(0, ntracks_day):
        print(f'{itrack}: {track_time[itrack]}')
        
        # Find closest grid point and time index in ERA5 
        # lat_idx = np.abs(lat_e5.values - mcs_lat[itrack]).argmin()
        # lon_idx = np.abs(lon_e5.values - mcs_lon[itrack]).argmin()
        t5_idx = np.abs(time_e5.values - track_time[itrack]).argmin()

        # Find closest time index in mask file
        tmask_idx = np.abs(time_mask.values - track_time[itrack]).argmin()

        # Current track number (+1 to match mask file)
        itrack_num = idx_track[itrack] + 1
        # Select matching time from the masks
        mask_time = mask_tracknumbers.isel(time=tmask_idx)
        # Get current mask, set everything else to 0
        _mask = mask_time.where(mask_time == itrack_num, other=0).load()
        # Count the number of grid points for the current mask
        ngrids_mask = np.count_nonzero(_mask)

        print(f' tmask_idx       {tmask_idx} ')
        print('     ')
        print(f'itrack              {itrack}')
        print('     ')
        print(f'itrack_num          {itrack_num}')
        print('     ')
        print(f'mask_time           {mask_time}')
        print('     ')
        print(f'ngrids_mask         {ngrids_mask}')
        print('     ')


        # Proceed if mask exist
        if (ngrids_mask > 0):

            # Select matching time from ERA5 DataSet
            #iT = dseT.isel(time=t5_idx)
            #iR = dseR.isel(time=t5_idx)
            iZ = dseZ.isel(time=t5_idx)
            iU = dseU.isel(time=t5_idx)
            iV = dseV.isel(time=t5_idx)
            iW = dseW.isel(time=t5_idx)
            iD = dseD.isel(time=t5_idx)
            iU10   = dseU10.isel(time=t5_idx)
            iV10   = dseV10.isel(time=t5_idx)
            iVIWVD = dseVIWVD.isel(time=t5_idx)

            # Subset ERA5 variables within the mask, 
            # setting drop=True crops the data outside the mask
            
            #_tk = iT['T'].where(_mask == itrack_num, drop=True)
            #_rh = iR['R'].where(_mask == itrack_num, drop=True)
            _z = iZ['Z'].where(_mask == itrack_num, drop=True) / 9.80665
            _z_sfc = z_sfc.where(_mask == itrack_num, drop=True)

            _u = iU['U'].where(_mask == itrack_num, drop=True).load()
            _v = iV['V'].where(_mask == itrack_num, drop=True).load()
            _w = iW['W'].where(_mask == itrack_num, drop=True).load()
            _d = iD['D'].where(_mask == itrack_num, drop=True).load()
            _u10 = iU10['VAR_10U'].where(_mask == itrack_num, drop=True).load()
            _v10 = iV10['VAR_10V'].where(_mask == itrack_num, drop=True).load()
            _viwvd = iVIWVD['VIWVD'].where(_mask == itrack_num, drop=True).load()

            #print(f'_viwvd:    {_viwvd}')

            #calculate height agl
            zagl = _z - _z_sfc
            zagl = zagl.where(zagl >= 0).load()

            ## Select matching time from mask DataSet
            #iPW = PW.isel(time=tmask_idx)
            ## Subset mask variables within the mask
            #_PW = iPW.where(_mask == itrack_num, drop=True)

            # Filter 3D variables below surface (replaced with -999)
            # They will not be included in searching for max ThetaE below 500 hPa for the most unstable level
            # Vertical coordinates (Z, P) are not filtered
            fillval = -999.
            #_tk_f = _tk.where(_z > _z_sfc, other=fillval).data
            #_rh_f = _rh.where(_z > _z_sfc, other=fillval).data

            _u_f = _u.where(_z > _z_sfc, other=fillval)
            _v_f = _v.where(_z > _z_sfc, other=fillval)
            _d_f = _d.where(_z > _z_sfc, other=np.NaN)
            _w_f = _w.where(_z > _z_sfc, other=np.NaN)   # You're onnly doing this at 600mb now, which should be well above the ground. If you do lower alts, you'll have to pay attention to this (making a 3D w above)



            # Make a 3D array of pressure by repeating the profile ny, nx times
            _nx = _u.sizes['longitude']
            _ny = _u.sizes['latitude']
            p3d = np.tile(pressure_pa, (_ny * _nx)).reshape(_nx, _ny, nlevels)
            # Swap dimension from 2 to 0 such that: [z, y, x]
            # p3d = np.swapaxes(p3d, 2, 0)
            # Transpose 3D pressure array to match the other variables: [z, y, x]
            p3d = np.transpose(p3d, (2,1,0))


            # JIM: add shear(0-3,0-6,3-9 kmagl)
            shearmag_2to9 = calc_shear_2level(_u_f, _v_f, zagl, 2000, 9000)
            mean_shearmag_2to9[itrack] =  np.nanmean(shearmag_2to9)
            max_shearmag_2to9[itrack]  =  np.nanmax(shearmag_2to9)
        
            shearmag_0to6 = calc_shear(6000., _u_f, _v_f, zagl, _u10, _v10)
            mean_shearmag_0to6[itrack] =  np.nanmean(shearmag_0to6)
            max_shearmag_0to6[itrack]  =  np.nanmax(shearmag_0to6)
        
            shearmag_0to2 = calc_shear(2000., _u_f, _v_f, zagl, _u10, _v10)
            mean_shearmag_0to2[itrack] =  np.nanmean(shearmag_0to2)
            max_shearmag_0to2[itrack]  =  np.nanmax(shearmag_0to2)

            # dynamic vars:
            meanOMEGA600[itrack]   = np.nanmean( _w_f.sel(level=600.) )
            minOMEGA600[itrack]    = np.nanmin( _w_f.sel(level=600.) )       
            minOMEGAsub600[itrack] = np.nanmin(  _w_f.sel( level=slice(1000.,600.) ) )  
        
            meanVIWVD[itrack] = np.nanmean(_viwvd)
            minVIWVD[itrack]  = np.nanmin(_viwvd)
            maxVIWVD[itrack]  = np.nanmax(_viwvd)
        
            meanDIV750[itrack]   = np.nanmean( _d_f.sel(level=750.) )
            minDIV750[itrack]    = np.nanmin(  _d_f.sel(level=750.) )
            minDIVsub600[itrack] = np.nanmin(  _d_f.sel( level=slice(1000.,600.) ) )


            # call wind dir/spd_600 here, take mean:
            u6 = _u_f.sel(level=600.).values
            v6 = _v_f.sel(level=600.).values
            u6[u6 < -99] = np.NaN
            v6[v6 < -99] = np.NaN
            mpwindmag600  =  np.sqrt( v6**2 + u6**2 )
            ## .metpy.dequantify() converts data back to a unit-naive array
            ## https://unidata.github.io/MetPy/latest/tutorials/xarray_tutorial.html?highlight=dequantify#
            u6 = u6 * units('m/s')
            v6 = v6 * units('m/s')
            mpwinddir600  =  metpy.calc.wind_direction( u6, v6)
            meanWNDSPD600[itrack]   =  np.nanmean( mpwindmag600 )
            meanWNDDIR600[itrack]   =  np.nanmean( mpwinddir600.magnitude )

            ostat = 0
            ## Call AFWA diagnostics on data filtered below surface
            #ostat, afwaMUCAPE, afwaMUCIN, afwaMULCL, afwaMULFC, afwaMUEL, afwaMULPL = afwa.diag_functions.diag_map(_tk_f, _rh_f, p3d, _z, 1, 1)
            #if ostat == 1:
            #    # Use a context manager to temporarily suppress the warning
            #    with warnings.catch_warnings():
            #        # Filter out the specific warning
            #        warnings.filterwarnings("ignore", category=RuntimeWarning)
            #        # Replace undefined values with NaN
            #        afwaMUCAPE[afwaMUCAPE < 0] = np.NaN
            #        afwaMUCIN[afwaMUCIN < -999] = np.NaN
            #        afwaMULCL[afwaMULCL < 0] = np.NaN
            #        afwaMULFC[afwaMULFC < 0] = np.NaN
            #        afwaMUEL[afwaMUEL < 0] = np.NaN
            #        afwaMULPL[afwaMULPL < 0] = np.NaN
            #        
            #        # Calculate stats of afwa vars:
            #        meanMUCAPE[itrack] = np.nanmean(afwaMUCAPE)
            #        meanMUCIN[itrack] = np.nanmean(afwaMUCIN)
            #        meanMULFC[itrack] = np.nanmean(afwaMULFC)
            #        meanMUEL[itrack] = np.nanmean(afwaMUEL)
            #
            #        maxMUCAPE[itrack] = np.nanmax(afwaMUCAPE)
            #        minMUCIN[itrack]  = np.nanmin(afwaMUCIN)
            #        #maxMULFC[itrack]  = np.nanmax(afwaMULFC)
            #        #maxMULCL[itrack]  = np.nanmax(afwaMULCL)
            #        #maxMUEL[itrack]   = np.nanmax(afwaMUEL)  
            #
            #        #minMUCAPE[itrack] = np.nanmin(afwaMUCAPE)
            #        #minMUCIN[itrack] = np.nanmin(afwaMUCIN)
            # 
            #        meanPW[itrack] = np.nanmean(_PW)
            #        maxPW[itrack] = np.nanmax(_PW)
            #        minPW[itrack] = np.nanmin(_PW)
        else:
            print(f'Warning: cannot find track number {itrack_num} in: {time_mask.data[tmask_idx]}')


        ### define attributes for output vars
        #MUCAPE_attrs = {'long_name': 'MU CAPE in area', 'units': 'J/kg' }
        #MUCIN_attrs  = {'long_name': 'MU CIN in area', 'units': 'J/kg' }
        ##MULCL_attrs  = {'long_name': 'MU LCL in area', 'units': 'm ASL'}
        #MULFC_attrs  = {'long_name': 'MU LFC in area', 'units': 'm ASL'}
        #MUEL_attrs   = {'long_name': 'MU EL in area', 'units': 'm ASL'}
        #PW_attrs = PW.attrs

        shear2to9_attrs   = {'long_name': 'Bulk shear in layer from 2 to 9 km agl', 'units': 'm/s'}
        shear0to2_attrs   = {'long_name': 'Bulk shear in layer from 10m to 2 km agl', 'units': 'm/s'}
        shear0to6_attrs   = {'long_name': 'Bulk shear in layer from 10m to 6 km agl', 'units': 'm/s'}
        omega_attrs   = {'long_name': 'Omega - vert motion', 'units': 'Pa/s'}
        VIWVD_attrs   = {'long_name': 'Vertical integral of water vap flux divergence', 'units': 'kg m-2 s-1'}
        div_attrs = {'long_name': '3D divergence', 'units': 's-1'}
        dir_attrs = {'long_name': 'in-mp wind direction at 600hpa', 'units': 'deg'}
        spd_attrs = {'long_name': 'in-mp wind speed at 600hpa', 'units': 'm/s'}

    # Put output variables to a dictionary for easier acceess
    var_dict = {
        #'meanMUCAPE':meanMUCAPE,
        #'maxMUCAPE':maxMUCAPE,
        #'meanMUCIN':meanMUCIN, 
        #'minMUCIN':minMUCIN, 
        #'meanMULFC':meanMULFC,
        #'meanMUEL':meanMUEL,
        #'meanPW':meanPW,
        #'maxPW':maxPW,
        #'minPW':minPW,

        'meanshearmag2to9':mean_shearmag_2to9,
        'maxshearmag2to9':max_shearmag_2to9,
        'meanshearmag0to2':mean_shearmag_0to2,
        'maxshearmag0to2':max_shearmag_0to2,
        'meanshearmag0to6':mean_shearmag_0to6,
        'maxshearmag0to6':max_shearmag_0to6,
        'meanOMEGA600':meanOMEGA600,
        'minOMEGA600':minOMEGA600,
        'minOMEGAsub600':minOMEGAsub600,
        'meanVIWVD':meanVIWVD,
        'minVIWVD':minVIWVD,
        'maxVIWVD':maxVIWVD,
        'meanDIV750':meanDIV750,
        'minDIV750':minDIV750,
        'minDIVsub600':minDIVsub600,
        'meanWNDSPD600':meanWNDSPD600,
        'meanWNDDIR600':meanWNDDIR600,
    }



    # Output variable attribute dictionary, the keys must match those in var_dict
    var_attrs = {
        #'meanMUCAPE':MUCAPE_attrs,
        #'maxMUCAPE':MUCAPE_attrs,
        #'meanMUCIN':MUCIN_attrs,
        #'minMUCIN':MUCIN_attrs,
        #'meanMULFC':MULFC_attrs,
        #'meanMUEL':MUEL_attrs,
        #'meanPW':PW_attrs,
        #'maxPW':PW_attrs,
        #'minPW':PW_attrs,
        'meanshearmag2to9':shear2to9_attrs,
        'maxshearmag2to9':shear2to9_attrs,
        'meanshearmag0to2':shear0to2_attrs,
        'maxshearmag0to2':shear0to2_attrs,
        'meanshearmag0to6':shear0to6_attrs,
        'maxshearmag0to6':shear0to6_attrs,        
        'meanOMEGA600':omega_attrs,
        'minOMEGA600':omega_attrs,
        'minOMEGAsub600':omega_attrs,
        'meanVIWVD':VIWVD_attrs,
        'minVIWVD':VIWVD_attrs,
        'maxVIWVD':VIWVD_attrs,        
        'meanDIV750':div_attrs,
        'minDIV750':div_attrs,
        'minDIVsub600':div_attrs,
        'meanWNDSPD600':spd_attrs,
        'meanWNDDIR600':dir_attrs,
    } 

    print(f'Done processing: {filenameT}')
    
    # import pdb; pdb.set_trace()
    return var_dict, var_attrs







def calc_shear_2level(u, v, z, level_lower, level_upper):
    """
    Calculates vertical wind shear and direction between two levels

    Args:
        u: xr.DataArray
            U components of wind.
        v: xr.DataArray
            V components of wind.
        z: xr.DataArray
            Height above ground level.
        level_lower: float
            Lower height level.
        level_upper: float
            Upper height level.    

    Returns:
        shear_mag: xr.DataArray
            Bulk wind shear magnitude.
        shear_dir: xr.DataArray
            Bulk wind shear direction.
    """

    # Interpolate U, V at lower & upper levels (on HAMSL coordinate)
    u_lower = interplevel(u, z, level_lower)
    v_lower = interplevel(v, z, level_lower)
    u_upper = interplevel(u, z, level_upper)
    v_upper = interplevel(v, z, level_upper)
    ## Calculate wind speed
    #wspd_lower = np.sqrt(u_lower**2 + v_lower**2)
    #wspd_upper = np.sqrt(u_upper**2 + v_upper**2)
    du = u_upper - u_lower
    dv = v_upper - v_lower

    ## Wind shear magnitude
    #shear_mag = wspd_upper - wspd_lower
    shear_mag = np.sqrt(du**2 + dv**2)

    ## Wind shear direction
    #ushear = u_upper - u_lower
    #vshear = v_upper - v_lower
    ## .metpy.dequantify() converts data back to a unit-naive array
    ## https://unidata.github.io/MetPy/latest/tutorials/xarray_tutorial.html?highlight=dequantify#
    #shear_dir = metpy.calc.wind_direction(ushear * units('m/s'), vshear * units('m/s')).metpy.dequantify()

    # Assign attributes
    shear_mag_attrs = {'long_name':f'Bulk wind shear magnitude between {level_lower}m and {level_upper}m', 'units':'m/s'}
    #shear_dir_attrs = {'long_name':f'Bulk wind shear direction between {level_lower}m and {level_upper}m', 'units':'degree'}
    shear_mag = shear_mag.assign_attrs(shear_mag_attrs)
    #shear_dir = shear_dir.assign_attrs(shear_dir_attrs)

    #return shear_mag, shear_dir
    return shear_mag






def calc_shear(level_shear, u, v, z_agl, u10, v10):
    """
    Calculates vertical wind shear and direction at specified AGL levels

    Args:
        level_shear: np.array(float)
            Vertical height level AGL (km).
        u: xr.DataArray
            U components of wind.
        v: xr.DataArray
            V components of wind.
        z_agl: xr.DataArray
            Height above ground level.
        u10: xr.DataArray
            10m U components of wind.
        v10: xr.DataArray
            10m V components of wind.    

    Returns:
        shear_mag: xr.DataArray
            Bulk wind shear magnitude.
        shear_dir: xr.DataArray
            Bulk wind shear direction.
    """
    # Interpolate U, V to specific AGL levels
    u_agl = interplevel(u, z_agl, level_shear)
    v_agl = interplevel(v, z_agl, level_shear)

    ## Calculate wind speed
    #wspd_agl = np.sqrt(u_agl**2 + v_agl**2)
    #wspd10 = np.sqrt(u10**2 + v10**2)
    du = u_agl - u10
    dv = v_agl - v10

    # Wind shear magnitude
    #shear_mag = wspd_agl - wspd10
    shear_mag = np.sqrt(du**2 + dv**2)

    ## Wind shear direction
    #ushear = u_agl - u10
    #vshear = v_agl - v10
    # # .metpy.dequantify() converts data back to a unit-naive array
    # # https://unidata.github.io/MetPy/latest/tutorials/xarray_tutorial.html?highlight=dequantify#
    #shear_dir = mpcalc.wind_direction(ushear * units('m/s'), vshear * units('m/s')).metpy.dequantify()

    # Assign attributes
    shear_mag_attrs = {'long_name':'Bulk wind shear magnitude', 'units':'m/s'}
    #shear_dir_attrs = {'long_name':'Bulk wind shear direction', 'units':'degree'}
    shear_mag = shear_mag.assign_attrs(shear_mag_attrs)
    #shear_dir = shear_dir.assign_attrs(shear_dir_attrs)

    #return shear_mag, shear_dir
    return shear_mag





if __name__ == "__main__":

    # Get inputs from command line arguments
    config_file = sys.argv[1]
    track_period = sys.argv[2]
    track_start = int(sys.argv[3])
    track_end = int(sys.argv[4])
    digits = int(sys.argv[5])

    # Get inputs from configuration file
    stream = open(config_file, 'r')
    config = yaml.full_load(stream)

    era5_dir = config.get('era5_dir')
    era5_terrain_file = config.get('era5_terrain_file')
    # for MPs
    stats_dir = config.get('stats_dir')
    mask_dir = config.get('mask_dir')
    output_dir = config.get('output_dir')
    trackstats_basename = config.get('trackstats_basename')
    trackmask_basename = config.get('trackmask_basename')
    output_basename = config.get('output_basename')
    ntimes_max = config['ntimes_max']
    level_lims = config.get('level_lims')
    # Parallel setup
    run_parallel = config.get('run_parallel')
    n_workers = config.get('n_workers')
    # Input track stats filename
    stats_file = f"{stats_dir}{trackstats_basename}{track_period}.nc"
    os.makedirs(output_dir, exist_ok=True)


    # Read track statistics file
    dss = xr.open_dataset(stats_file)
    # Subset MCS times to reduce array size
    # Most valid MCS data are within 0:ntimes_max
    dss = dss.isel(times=slice(0, ntimes_max))
    ntracks_all = dss.sizes['tracks']

    # Make output filename
    track_start_str = str(track_start).zfill(digits)
    outfilename = f"{output_dir}{output_basename}{track_period}_t{track_start_str}.nc"
    print(f'stats_file:     {stats_file}')
    print(f'outfile:      {output_dir}{outfilename}')

    # Subset tracks for this part
    dss = dss.sel(tracks=slice(track_start, track_end))
    coord_tracks = dss['tracks']
    coord_times = dss['times']
    ntracks = dss.sizes['tracks']
    ntimes = dss.sizes['times']

    # Get end times for all tracks
    tracks_basetime = dss.base_time
    # Sum over time dimension for valid basetime indices, -1 to get the last valid time index for each track
    # This is the end time index of each track (i.e. +1 equals the lifetime of each track)
    end_time_idx = np.sum(np.isfinite(tracks_basetime), axis=1)-1
    # Apply fancy indexing to base_time: a tuple that indicates for each track, get the end time index
    end_basetime = tracks_basetime[(np.arange(0,ntracks), end_time_idx)]

    # Get the min/max of all base_times
    min_basetime = tracks_basetime.sel(times=0).min()
    max_basetime = end_basetime.max()
    
    # Make a date list that includes all tracks
    tracks_alldates = pd.date_range(start=min_basetime.values, end=max_basetime.values, freq='1D')
    # Convert all track times and ERA5 times to date strings
    tracks_dates = tracks_basetime.dt.strftime('%Y%m%d')
    # ERA5 data directory is organized by month (yyyymm)
    dirs_month = tracks_alldates.strftime("%Y%m")
    # 3D data is in daily files
    files3d_day = tracks_alldates.strftime("%Y%m%d")
    nfiles = len(tracks_alldates)

    # TESTER: setting nfiles to a smaller number for testing
    #nfiles = 1
    print(f"Total number of ERA5 files: {nfiles}")


    # Create a list to store matchindices for each ERA5 file
    trackindices_all = []
    timeindices_all = []
    results = []

    p_filenameZ = []
    p_filenameT = []
    p_filenameRH = []
    p_filenameU = []
    p_filenameV = []
    p_filenameW = []
    p_idx_track = []
    p_track_time = []
    p_level_lims = []
    p_filenameU10 = []
    p_filenameV10 = []
    p_filenameVIWVD = []
    p_filenameD = []
    p_iday = []

    #inputs in lists (for parallelization)
    p1_args = []


    # Loop over dates that have MCSs in them
    for ifile in range(nfiles):
        idir = dirs_month[ifile]
        iday = files3d_day[ifile]
        print(iday)

        imonth = iday[0:6]
                
        # 3d era5 var files for the day: 
        filenameT = f"{era5_dir}{idir}/e5.oper.an.pl.128_130_t.ll025sc.{iday}00_{iday}23.nc"
        filenameRH = f"{era5_dir}{idir}/e5.oper.an.pl.128_157_r.ll025sc.{iday}00_{iday}23.nc"
        filenameU = f"{era5_dir}{idir}/e5.oper.an.pl.128_131_u.ll025uv.{iday}00_{iday}23.nc"
        filenameV = f"{era5_dir}{idir}/e5.oper.an.pl.128_132_v.ll025uv.{iday}00_{iday}23.nc"
        filenameZ = f"{era5_dir}{idir}/e5.oper.an.pl.128_129_z.ll025sc.{iday}00_{iday}23.nc"
        filenameW = f"{era5_dir}{idir}/e5.oper.an.pl.128_135_w.ll025sc.{iday}00_{iday}23.nc"
        filenameD = f"{era5_dir}{idir}/e5.oper.an.pl.128_155_d.ll025sc.{iday}00_{iday}23.nc"

        itimestamp = tracks_alldates[ifile]
        ieday = (itimestamp + MonthEnd(0)).strftime("%Y%m%d")

        print(f'ieday    {ieday}')
        print(f'MonthEnd(1)    {MonthEnd(1)}')
        print(f'MonthEnd(0)    {MonthEnd(0)}')
        print(f'itimestamp    {itimestamp}')

        filenameU10   =  f"{era5_dir}{idir}/e5.oper.an.sfc.128_165_10u.ll025sc.{imonth}0100_{ieday}23.nc"
        filenameV10   =  f"{era5_dir}{idir}/e5.oper.an.sfc.128_166_10v.ll025sc.{imonth}0100_{ieday}23.nc"
        filenameVIWVD =  f"{era5_dir}{idir}/e5.oper.an.vinteg.162_084_viwvd.ll025sc.{imonth}0100_{ieday}23.nc"
        print(f'fileVIWVD   {filenameVIWVD}')
        print(f'fileW   {filenameW}')


        # These tracks use the same ERA5 file
        idx_track, idx_time = np.where(tracks_dates == files3d_day[ifile])
        
        #print(f'idx_track     {idx_track}')
        #print('    ')
        #print(f'idx_time      {idx_time}')
        #print('     ')
        #print(f'tracks_dates       {tracks_dates}')
        #print('    ')
        #print(f'files3d_day[ifile]       {files3d_day[ifile]}')
        #print('     ')



        # Get coordinates from indices
        # This aligns with the full track dataset
        _coord_tracks = coord_tracks.data[idx_track]
        # _coord_times = coord_times.data[idx_time]

        # Save track/time indices for the current ERA5 file to the overall list
        trackindices_all.append(idx_track)
        timeindices_all.append(idx_time)

        # Get the track lat/lon/time values in the same day
        track_time = tracks_basetime.values[idx_track, idx_time]

        # check if there are MCSs at current era5 time:
        tracks_present =  len(track_time) 
        print(f'tracks_present   {tracks_present} ')

        # Put inputs in lists (for parallelization)
        p_filenameZ.append(filenameZ)
        p_filenameT.append(filenameT)
        p_filenameRH.append(filenameRH)
        p_filenameU.append(filenameU)
        p_filenameV.append(filenameV)
        p_filenameU10.append(filenameU10)
        p_filenameV10.append(filenameV10)
        p_filenameW.append(filenameW)
        p_filenameVIWVD.append(filenameVIWVD)
        p_filenameD.append(filenameD)
        #p_idx_track.append(idx_track)
        p_idx_track.append(_coord_tracks)
        p_track_time.append(track_time)
        p_level_lims.append(level_lims)
        p_iday.append(iday)



        #p1_args.append((filenameZ, filenameT, filenameRH, filenameU, filenameV, _coord_tracks, track_time, level_lims))

        p1_args.append((filenameZ, filenameT, filenameRH, filenameU, filenameV, filenameW, filenameD, filenameU10, filenameV10, filenameVIWVD, _coord_tracks, track_time, level_lims, iday))



        # if mcs present at era5 time 
        if tracks_present > 0:
            # Serial
            if run_parallel == 0:
                # Call function to calculate statistics
                #result = calc_era5_prof(
                #    p_filenameZ[ifile], 
                #    p_filenameT[ifile], 
                #    p_filenameRH[ifile], 
                #    p_filenameU[ifile], 
                #    p_filenameV[ifile], 
                #    p_idx_track[ifile], 
                #    p_track_time[ifile], 
                #    p_level_lims[ifile],
                #)
                #results.append(result)          
        # end for ifile in range(nfiles):

                # Call function to calculate statistics
                result = calc_era5_prof(
                    filenameZ,
                    filenameT,
                    filenameRH,
                    filenameU,
                    filenameV,
                    filenameW,
                    filenameD,
                    filenameU10,
                    filenameV10,
                    filenameVIWVD,
                    idx_track,
                    track_time,
                    level_lims,
                    iday,
                )
                results.append(result)
          # end for ifile in range(nfiles):


    # Parallel
    if run_parallel == 1:
        # Joblib
        #results = Parallel(n_jobs=n_workers)(
        #    delayed(calc_era5_prof)(
        #        p_filenameZ[ifile], 
        #        p_filenameT[ifile], 
        #        p_filenameRH[ifile], 
        #        p_filenameU[ifile], 
        #        p_filenameV[ifile], 
        #        p_idx_track[ifile], 
        #        p_track_time[ifile], 
        #        p_level_lims[ifile],
        #    ) for ifile in range(0, nfiles)
        #)
        # Multiprocessing
        pool = Pool(n_workers)
        results = pool.starmap(calc_era5_prof, p1_args)
        pool.close()

    # Final returned outputs
    final_result = results

    #-------------------------------------------------------------------------
    # Collect returned data and write to output
    #-------------------------------------------------------------------------

    # Make a variable list and get attributes from one of the returned dictionaries
    # Loop over each return results till one that is not None
    counter = 0
    while counter < nfiles:
        if final_result[counter] is not None:
            var2d_names = list(final_result[counter][0].keys())
            var_attrs = final_result[counter][1]
            break
        counter += 1

    # Loop over variable list to create the dictionary entry
    out_dict = {}
    out_dict_attrs = {}
    for ivar in var2d_names:
        out_dict[ivar] = np.full((ntracks, ntimes), np.NaN, dtype=np.float32)
        out_dict_attrs[ivar] = var_attrs[ivar]

    # Put the results to output track stats variables
    # Loop over each file (parallel return results)
    for ifile in range(nfiles):
        # Get the return results for this pixel file
        iVAR2d = final_result[ifile][0]
        # iVAR3d = final_result[ifile][1]
        if iVAR2d is not None:
            trackindices = trackindices_all[ifile]
            timeindices = timeindices_all[ifile]
            # Loop over each variable and assign values to output dictionary
            for ivar in var2d_names:
                if iVAR2d[ivar].ndim == 1:
                    out_dict[ivar][trackindices,timeindices] = iVAR2d[ivar]

    # Define a dataset containing all variables
    var_dict = {}
    # Define output variable dictionary
    for key, value in out_dict.items():
        if value.ndim == 2:
            var_dict[key] = (['tracks', 'times'], value, out_dict_attrs[key])

    # Define coordinate list
    coord_dict = {
        'tracks': (['tracks'], coord_tracks.data, coord_tracks.attrs),
        'times': (['times'], coord_times.data, coord_times.attrs),
    }

    # Define global attributes
    gattr_dict = {
        'Title': 'Track environments',
        'Created_on': time.ctime(time.time()),
    }

    # Define output Xarray dataset
    dsout = xr.Dataset(var_dict, coords=coord_dict, attrs=gattr_dict)

    # Set encoding/compression for all variables
    comp = dict(zlib=True, dtype='float32')
    encoding = {var: comp for var in dsout.data_vars}

    # Write to netcdf file
    dsout.to_netcdf(path=outfilename, mode='w', format='NETCDF4', unlimited_dims='tracks', encoding=encoding)
    print(f'Output saved as: {outfilename}')

   
